# cruzcristiana-gnome
Muestra la cruz de Cristo en la barra de GNOME
